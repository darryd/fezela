dofile "util.lua";
dofile "eval.lua";
dofile "covers.lua";
dofile "valid_moves.lua";

function love.load()


	iTeam = "w"

	-- chess pieces
	pawn 	= { moves_f = v_moves_pawn };
	rook 	= { moves_f = v_moves_rook };
	knight 	= { moves_f = v_moves_knight };
	bishop 	= { moves_f = v_moves_bishop };
	queen 	= { moves_f = v_moves_queen };
	king 	 = { moves_f = v_moves_king };

	-- white chess pieces
	white_pawn   = { piece = pawn,   ch = "p", side = "w", covers_f = covers_pawn_white };
	white_rook   = { piece = rook,   ch = "r", side = "w", covers_f = covers_rook };
	white_knight = { piece = knight, ch = "h", side = "w", covers_f = covers_knight }; 
	white_bishop = { piece = bishop, ch = "b", side = "w", covers_f = covers_bishop };
	white_queen  = { piece = queen,  ch = "q", side = "w", covers_f = covers_queen };
	white_king   = { piece = king,   ch = "k", side = "w", covers_f = covers_king };

	-- black chess pieces
	black_pawn   = { piece = pawn,   ch = "P", side = "b", covers_f = covers_pawn_black };
	black_rook   = { piece = rook,   ch = "R", side = "b", covers_f = covers_rook };
	black_knight = { piece = knight, ch = "H", side = "b", covers_f = covers_knight };
	black_bishop = { piece = bishop, ch = "B", side = "b", covers_f = covers_bishop };
	black_queen  = { piece = queen,  ch = "Q", side = "b", covers_f = covers_queen };
	black_king   = { piece = king,   ch = "K", side = "b", covers_f = covers_king };


	old = {}
	new = {}


	old.row = 0
  	old.column = 0

	new.row = 0
  	new.column = 0

	drag = false
	iDrag = -1
	rClick = 0
	moving = false
	targetX = 0
	targetY = 0


	pawn = love.graphics.newImage("pawn.png")
	rook = love.graphics.newImage("rook.png")

 	board = set_board();
end


-- 2 2 to 3 2 
function love.mousepressed( x, y, button )

	if button == "l" then 
		for i = 1, 8 do
			for j = 1, 8 do

					if isClickedOn( x, y, (i - 1), (j - 1) ) then
						old.row = i
						old.column = j

						new.row = 0
						new.column = 0
					end
			end
		end

	elseif button == "r" then 
		new.row = math.floor( x / 64 ) + 1
		new.column = math.floor( y / 64 ) + 1
	else 
		 old = { row = 2, column = 2 }
		 new = { row = 3, column = 2 }
	end
end

function love.mousereleased( x, y, button )
	-- Attempt to move
	x = math.floor(x / 64)
	y = math.floor(y / 64)


	if iDrag == -1 then
		return
	end

	iDrag = -1
end

function love.draw()

	-- Drawing the squares -- 
	for i = 1, 8 do
		for j = 1, 8 do
			if( board[i][j] ~= 0 ) then
				if ( i % 2 ) == ( j % 2 ) then
					love.graphics.setColor(255, 255, 255)
				else
					love.graphics.setColor(25, 25, 25)
				end

				love.graphics.rectangle( "fill", (i - 1) * 64, (j - 1) * 64, 64, 64 )

				if( board[i][j] ~= nil ) then

					if board[i][j].kind.side == "w"  then
						love.graphics.setColor(255, 255, 255)
						love.graphics.rectangle( "fill", (i - 1) * 64, (j - 1) * 64, 64, 64 )
						love.graphics.setColor(0, 0, 0)
					elseif board[i][j].kind.side == "b" then
						love.graphics.setColor(0, 0, 0)
						love.graphics.rectangle( "fill", (i - 1) * 64, (j - 1) * 64, 64, 64 )
						love.graphics.setColor(255, 255, 255)
					end

					love.graphics.print( board[i][j].kind.ch, (i - 1 ) * 64, (j - 1) * 64)
				end
			end
		end
	end

	if old.row ~= 0 and old.column ~= 0 then
		love.graphics.setColor(40, 40, 80)
		love.graphics.rectangle( "fill", (old.row - 1) * 64, (old.column - 1) * 64, 64, 64 )
	end

	if new.row ~= 0 and new.column ~= 0 then
		love.graphics.setColor(80, 40, 80)
		love.graphics.rectangle( "fill", (new.row - 1) * 64, (new.column - 1) * 64, 64, 64 )
	end


	love.graphics.setColor(255, 255, 0)
	love.graphics.print( old.row .. " " .. old.column, 550, 20)
	love.graphics.print( new.row .. " " .. new.column, 550, 40)

	local bool = is_valid_move(board, old, new, "w")

	if bool == true then
		love.graphics.print( "True", 550, 60)
	else
		love.graphics.print( "False", 550, 60)
	end
	

end

function love.update( dt )

	local old_pos = old
	local new_pos = new	

    if is_valid_move(board, old_pos, new_pos, "w") then

	    move (board, old_pos, new_pos);

	    -- AI move -- 
	    board = get_best_board_ex(get_moves_for_side(board, "b"), "b", 2);

	    if board == nil then
	      print ("\nGame Over!");
	      love.event.quit()
	    end

	    -- check for stale/check mate --
	    tmp_board = copy_board(board);
	    tmp_board = get_best_board_ex(get_moves_for_side(board, "w"), "w");

	    if tmp_board == nil then
	      print ("\nGame Over!");
	      love.event.quit()
	    end

	end
end

function isClickedOn( x1, y1, x2, y2 )
	if x1 >= x2 * 64 and y1 >= y2 * 64 and x1 <= x2 * 64 + 64 and y1 <= y2 * 64 + 64 then
		return true
	end
	return false
end

-- This function moves a piece to anywhere. It doesn't check if is legal
function move(board, old_pos, new_pos) 

  board[new_pos.row][new_pos.column] = board[old_pos.row][old_pos.column]
  board[old_pos.row][old_pos.column] = nil;

  return board;
end

-- Returns a board with all the pieces set to the starting positions
function set_board() 

  -- Start off with a new blank chess board
  local board = {};
  local i;
  for i=1, 8, 1 do
    board[i] = {};
  end;

  -- Set white side
  -- set the pawns
  for i=1, 8, 1 do
    board[2][i] =  { kind = white_pawn };
  end
  -- now the other pieces
  board[1][1] = { kind = white_rook };
  board[1][2] = { kind = white_knight };
  board[1][3] = { kind = white_bishop };
  board[1][4] = { kind = white_queen };
  board[1][5] = { kind = white_king };
  board[1][6] = { kind = white_bishop };
  board[1][7] = { kind = white_knight };
  board[1][8] = { kind = white_rook };

  --Set black side

  -- set the pawns
  for i=1, 8, 1 do
    board[7][i] = { kind = black_pawn } ;
  end
  -- now the other pieces
  board[8][1] = { kind = black_rook };
  board[8][2] = { kind = black_knight };
  board[8][3] = { kind = black_bishop };
  board[8][4] = { kind = black_queen };
  board[8][5] = { kind = black_king };
  board[8][6] = { kind = black_bishop };
  board[8][7] = { kind = black_knight };
  board[8][8] = { kind = black_rook };


  return board;
end