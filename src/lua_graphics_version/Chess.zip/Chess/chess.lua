#!  /usr/bin/lua
dofile "util.lua";
dofile "eval.lua";
dofile "covers.lua";
dofile "valid_moves.lua";
dofile "input.lua";
--dofile "moves.lua";

print ("chess\n");

-- colours for displaying on terminal
-- vt100 codes:
disp_default = '\27[0m'; -- Reset
disp_white_side = '\27[31m'; -- Red
disp_black_side = '\27[36m'; -- Cyan

-- chess pieces
pawn = { moves_f = v_moves_pawn };
rook = { moves_f = v_moves_rook };
knight = { moves_f = v_moves_knight };
bishop = { moves_f = v_moves_bishop };
queen = { moves_f = v_moves_queen };
king = { moves_f = v_moves_king };

-- white chess pieces
white_pawn   = { piece = pawn,   ch = "p", side = "w", covers_f = covers_pawn_white };
white_rook   = { piece = rook,   ch = "r", side = "w", covers_f = covers_rook };
white_knight = { piece = knight, ch = "h", side = "w", covers_f = covers_knight }; 
white_bishop = { piece = bishop, ch = "b", side = "w", covers_f = covers_bishop };
white_queen  = { piece = queen,  ch = "q", side = "w", covers_f = covers_queen };
white_king   = { piece = king,   ch = "k", side = "w", covers_f = covers_king };

-- black chess pieces
black_pawn   = { piece = pawn,   ch = "P", side = "b", covers_f = covers_pawn_black };
black_rook   = { piece = rook,   ch = "R", side = "b", covers_f = covers_rook };
black_knight = { piece = knight, ch = "H", side = "b", covers_f = covers_knight };
black_bishop = { piece = bishop, ch = "B", side = "b", covers_f = covers_bishop };
black_queen  = { piece = queen,  ch = "Q", side = "b", covers_f = covers_queen };
black_king   = { piece = king,   ch = "K", side = "b", covers_f = covers_king };

-- Return an empty board
function empty_board()

  local board;

  board = {};
  for i=1, 8, 1 do
    board[i] = {};
  end

  return board;
end


-- Returns a board with all the pieces set to the starting positions
function set_board() 

  -- Start off with a new blank chess board
  local board = {};
  local i;
  for i=1, 8, 1 do
    board[i] = {};
  end;

  -- Set white side
  -- set the pawns
  for i=1, 8, 1 do
    board[2][i] =  { kind = white_pawn };
  end
  -- now the other pieces
  board[1][1] = { kind = white_rook };
  board[1][2] = { kind = white_knight };
  board[1][3] = { kind = white_bishop };
  board[1][4] = { kind = white_queen };
  board[1][5] = { kind = white_king };
  board[1][6] = { kind = white_bishop };
  board[1][7] = { kind = white_knight };
  board[1][8] = { kind = white_rook };

  --Set black side

  -- set the pawns
  for i=1, 8, 1 do
    board[7][i] = { kind = black_pawn } ;
  end
  -- now the other pieces
  board[8][1] = { kind = black_rook };
  board[8][2] = { kind = black_knight };
  board[8][3] = { kind = black_bishop };
  board[8][4] = { kind = black_queen };
  board[8][5] = { kind = black_king };
  board[8][6] = { kind = black_bishop };
  board[8][7] = { kind = black_knight };
  board[8][8] = { kind = black_rook };

  return board;
end





function print_board(board) 

  local i, j;

  print(disp_default);

  for i=8, 1, -1 do

    io.write (i);
    io.write (" ");
    for j=1, 8, 1 do

      if board[i][j] == nil then
	
	-- display " ." for white scuares
	-- display " +" for black squares

	if (i % 2 == 0 and j % 2 == 0) or (i % 2 ~= 0 and j % 2 ~= 0) then
	  io.write(" +");
	else
	  io.write(" .");
	end


      else
	if board[i][j].kind.side == "w" then
	  io.write(disp_white_side);
	else
	  io.write(disp_black_side);
	end

    	io.write (" ");
	io.write(board[i][j].kind.ch);
	io.write(disp_default);
      end
    end
    print("");


  end 
  -- Print a b c d e f g h
  print("");
  io.write('   ');
  for j=1, 8, 1 do
    io.write(string.char(string.byte('a', 1) + j-1));
    io.write(' ');
  end
  print("\n");

  score_w, white_in_check, black_in_check, is_check_mate = score_white(board);

  --print("Score white: ", score_w);
  --print("Score black: ", score_black(board));

  print("White in check: ", white_in_check);
  print("Black in check: ", black_in_check);
  -- print("Check mate: ", is_check_mate); -- This isn't quite working
end

-- This function moves a piece to anywhere. It doesn't check if is legal
function move(board, old_pos, new_pos) 

  board[new_pos.row][new_pos.column] = board[old_pos.row][old_pos.column]
  board[old_pos.row][old_pos.column] = nil;

  return board;

end



function play_game_v4()

  board = set_board();
  io.write('\27[2J\27[;H');
  print_board(board);

  while true do

    print ("\nEnter move:");
    old_pos, new_pos = get_user_move();
    --while not is_on_board(old_pos) or not is_on_board(new_pos) do
    while not is_valid_move(board, old_pos, new_pos, "w") do
      print ("invalid move");
      old_pos, new_pos = get_user_move();
    end

    move (board, old_pos, new_pos);
    io.write('\27[2J\27[;H');
    print_board(board);

    print ("\nthinking...");

    -- ai
    board = get_best_board_ex(get_moves_for_side(board, "b"), "b", 2);
    if board ~= nil then

      -- chr(27) . "[2J" . chr(27) . "[;H";
      io.write('\27[2J\27[;H');


      print_board(board);
    else 
      print ("\nGame Over!");
      break;
    end

    -- check for stale/check mate
    tmp_board = copy_board(board);
    tmp_board = get_best_board_ex(get_moves_for_side(board, "w"), "w");
    if tmp_board == nil then
      print ("\nGame Over!");
      break;
    end
  end
end

play_game_v4();

--play_game_v1();
