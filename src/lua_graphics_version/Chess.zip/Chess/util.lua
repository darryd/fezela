#! /usr/bin/lua

function opponent_side(side) 

  if side == "w" then
    return "b";
  else
    return "w";
  end
end

function is_on_board(position) 

  return position.row >= 1 and position.row <= 8 and position.column >= 1 and position.row <= 8;

end

-- Returns a copy of a board
function copy_board(board)

  copy = {};

  for i=1, 8, 1 do

    copy[i] = {};
    for j=1, 8, 1 do

      if board[i][j] ~= nill then
	copy[i][j] = { kind = board[i][j].kind };
      end

    end
  end

  return copy;
end

