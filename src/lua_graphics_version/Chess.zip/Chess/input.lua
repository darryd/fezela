#!  /usr/bin/lua

-- example str is 'a5'
function str_to_pos(str)

  r = string.gfind(str, "%d");
  col = string.gfind(str, "%a");


  row = string.byte(r()) - string.byte('1') + 1;
  column = string.byte(col()) - string.byte('a') + 1;

  return { row = row, column = column };

end

-- Get move from user
function get_user_move()

  input = io.read();
 
  while not string.find(input, "^%s*%a%d%s+%a%d%s*$") do

    --[[
    if string.find("quit") then
      break;
    end
    --]]

    print ("Enter move as \"[column][row] [column][row]\"");
    print ("eg) \"a2 a4");
    input = io.read();

  end

  pos_str = string.gfind(input, "%a%d");

  old_pos = str_to_pos(pos_str());
  new_pos = str_to_pos(pos_str());

  return old_pos, new_pos;
end

